

<?php $__env->startSection('TituloPagina',"crear un nuevo registro"); ?>

<?php $__env->startSection('contenido'); ?>

<br>
<div class="card">
    <h5 class="card-header">Añadir</h5>
    <div class="card-body">
        <p class="card-text">
            <form action="<?php echo e(route('productos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label for="">Nombre</label>
                <input type="text" name="nombre" class="form-control" required>
                <label for="">Peso por unidad (gr)</label>
                <input type="text" name="peso_unitario_gr" class="form-control" required>
                <label for="">Cantidad</label>
                <input type="text" name="cantidad" class="form-control" required>
                <label for="perecedero" class="form-check-label">Perecedero</label>

                <div class="form-check">
                    <div class="form-check-input-container">
                        <input type="checkbox" id="perecedero" name="perecedero" class="form-check-input" value="1">
                    </div>
                </div>
                
                <button class="btn btn-primary">Añadir</button>
                <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-info">Volver</a>
            </form>
        </p>
    </div>
  </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\apiProductos\resources\views/agregar.blade.php ENDPATH**/ ?>