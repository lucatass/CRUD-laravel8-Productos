

<?php $__env->startSection('TituloPagina',"crear un nuevo registro"); ?>

<?php $__env->startSection('contenido'); ?>

<br>
<div class="card">
    <h5 class="card-header">Actualizar</h5>
    <div class="card-body">

        <p class="card-text">
            <form action="<?php echo e(route('producto.update', $producto->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PUT"); ?>
                <label for="">Nombre</label>
                <input type="text" name="nombre" class="form-control" required value="<?php echo e($producto->nombre); ?>">
                <label for="">Peso por unidad (gr)</label>
                <input type="text" name="peso_unitario_gr" class="form-control" required value="<?php echo e($producto->peso_unitario_gr); ?>">
                <label for="">Cantidad</label>
                <input type="text" name="cantidad" class="form-control" required value="<?php echo e($producto->cantidad); ?>">
                <label for="perecedero" class="form-check-label">Perecedero</label>

                <div class="form-check">
                    <div class="form-check-input-container">
                        <input type="checkbox" id="perecedero" name="perecedero" class="form-check-input"  value="<?php echo e($producto->perecedero); ?>">
                    </div>
                </div>
                
                <button class="btn btn-warning">Actualizar</button>
                <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-info">Volver</a>
            </form>
        </p>
    </div>
  </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\apiProductos\resources\views/actualizar.blade.php ENDPATH**/ ?>