<?php $__env->startSection('tituloPagina', 'Crud con Laravel 8'); ?>

<?php $__env->startSection('contenido'); ?>
<br>
<div class="card">
    <h5 class="card-header">Productos (laravel8 y MySQL)</h5>
    <div class="card-body">
        <div class="row">
            <div class="col-sm-12">
                
                <?php if($mensaje = Session::get('success')): ?>
                <div class="alert alert-success" role="alert"> 
                    <?php echo e($mensaje); ?>

                </div>
                <?php endif; ?>

            </div>
        </div>
        <p>
            <a href="<?php echo e(route('producto.create')); ?>" class="btn btn-primary"><span class="fas fa-cart-plus"></span>
                Añadir nuevo producto</a>
        </p>
        <p class="card-text">
            <div class="table table-responsive">
                <table class="table table-sm table-bordered">
                    <thead>
                            <th>nombre</th>
                            <th>peso por unidad (gr)</th>
                            <th>cantidad</th>
                            <th>perecedero</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                    </thead>
                    <tbody>
                <?php $__currentLoopData = $producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dato->nombre); ?></td>
                        <td><?php echo e($dato->peso_unitario_gr); ?></td>                        
                        <td><?php echo e($dato->cantidad); ?></td>                        
                        <td><?php if($dato->perecedero == 1): ?>
                                Si
                            <?php else: ?>
                                No
                            <?php endif; ?>
                        </td>
                        <td>
                            <form action="<?php echo e(route('producto.edit', $dato->id)); ?>" method="GET">
                                <button class="btn btn-warning btn-sm">
                                    <span class="fa fa-pencil"></span>
                                </button>
                            </form>
                        </td>
                        <td>
                            <form action="<?php echo e(route('producto.show', $dato->id)); ?>" method="GET">
                                <button class="btn btn-danger btn-small">
                                    <span class="fa fa-trash"></span>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </p>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\apiProductos\resources\views/inicio.blade.php ENDPATH**/ ?>