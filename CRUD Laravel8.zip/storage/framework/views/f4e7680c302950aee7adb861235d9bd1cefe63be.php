

<?php $__env->startSection('TituloPagina',"crear un nuevo registro"); ?>

<?php $__env->startSection('contenido'); ?>

<br>
<div class="card">
    <h5 class="card-header">Eliminar</h5>
    <div class="card-body">
        <p class="card-text">
            <div class="alert alert-danger" role="alert">
                Este producto se eliminará permanentemente ¿Desea proceder?
              </div>
            <table class="table table-sm table-hover table-bordered" style="background-color: rgb(206, 82, 82)">
                <thead>
                        <th>nombre</th>
                        <th>peso por unidad (gr)</th>
                        <th>cantidad</th>
                        <th>perecedero</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td><?php echo e($producto->peso_unitario_gr); ?></td>                        
                    <td><?php echo e($producto->cantidad); ?></td>                        
                    <td><?php echo e($producto->perecedero); ?></td>
                </tr>
                </tbody>
            </table>
            <br>
            <form action="<?php echo e(route('producto.destroy', $producto -> id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <a href="<?php echo e(route('productos.index')); ?>">Cancelar</a>
                <button class="btn btn-danger btn-small">
                    <span class="fa fa-trash">Eliminar</span>
                </button>
            </form>

        </p>
    </div>
  </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\apiProductos\resources\views/eliminar.blade.php ENDPATH**/ ?>