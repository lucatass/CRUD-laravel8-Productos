<?php $__env->startSection('tituloPagina', 'Crud con Laravel 8'); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <h1>hola usando layouts
        <i class="fab fa-500px"></i>
        </h1>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\apiProductos\resources\views/welcome.blade.php ENDPATH**/ ?>